const socket = io();

// Obtém o nome da sala da URL
const roomId = window.location.pathname.split('/')[1]; // Define o ID da sala com base na URL
const userId = 'user' + Math.floor(Math.random() * 1000); // Gera um ID de usuário aleatório.

let localStream;
let remoteStream;
let peerConnection;
let mediaRecorder;
let recordedChunks = [];
let isAudioMuted = false;
let isVideoMuted = false;
let participantCount = 0;

const localVideo = document.getElementById('localVideo');
const remoteVideo = document.getElementById('remoteVideo');
const muteAudioButton = document.getElementById('muteAudio');
const muteVideoButton = document.getElementById('muteVideo');
const leaveRoomButton = document.getElementById('leaveRoom');
const audioMeter = document.getElementById('audioMeter');
const micMutedIcon = document.getElementById('micMutedIcon');
const videoMutedIcon = document.getElementById('videoMutedIcon');
const leaveMessage = document.getElementById('leaveMessage');
const controls = document.getElementById('controls');

const servers = {
    iceServers: [
        {
            urls: "stun:stun.l.google.com:19302"
        }
    ]
};

// Função para ajustar o layout dos vídeos
function adjustVideoLayout() {
    if (participantCount > 1) {
        remoteVideo.style.width = '100%';
        remoteVideo.style.height = 'calc(100% - 50px)';
        localVideo.style.width = '200px';
        localVideo.style.height = '150px';
        localVideo.style.position = 'absolute';
        localVideo.style.bottom = '60px';
        localVideo.style.right = '20px';
    } else {
        localVideo.style.width = '10px';
        localVideo.style.height = 'calc(100% - 50px)';
        localVideo.style.position = 'relative';
        localVideo.style.bottom = 'auto';
        localVideo.style.right = 'auto';
        remoteVideo.style.width = '0';
        remoteVideo.style.height = '0';
    }
}

// Função para iniciar o vídeo local e configurar a conexão peer-to-peer
async function startVideo() {
    // Obtém a mídia local (vídeo e áudio)
    localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    localVideo.srcObject = localStream;

    // Configura a conexão peer-to-peer
    peerConnection = new RTCPeerConnection(servers);

    // Adiciona as trilhas de mídia local à conexão peer-to-peer
    localStream.getTracks().forEach(track => {
        peerConnection.addTrack(track, localStream);
    });

    // Recebe as trilhas de mídia remota e as adiciona ao vídeo remoto
    peerConnection.ontrack = event => {
        if (!remoteStream) {
            remoteStream = new MediaStream();
            remoteVideo.srcObject = remoteStream;
        }
        remoteStream.addTrack(event.track);
        participantCount++;
        adjustVideoLayout();
    };

    // Envia os candidatos ICE para a outra parte
    peerConnection.onicecandidate = event => {
        if (event.candidate) {
            socket.emit('candidate', roomId, event.candidate);
        }
    };

    // Cria uma oferta e a envia para a outra parte
    const offer = await peerConnection.createOffer();
    await peerConnection.setLocalDescription(offer);
    socket.emit('offer', roomId, offer);

    // Inicia o medidor de áudio
    startAudioMeter();
}

socket.on('offer', async offer => {
    await peerConnection.setRemoteDescription(new RTCSessionDescription(offer));
    const answer = await peerConnection.createAnswer();
    await peerConnection.setLocalDescription(answer);
    socket.emit('answer', roomId, answer);
});

socket.on('answer', async answer => {
    await peerConnection.setRemoteDescription(new RTCSessionDescription(answer));
});

socket.on('candidate', async candidate => {
    await peerConnection.addIceCandidate(new RTCIceCandidate(candidate));
});

// Função para iniciar a gravação do vídeo local
function startRecording() {
    recordedChunks = [];
    mediaRecorder = new MediaRecorder(localStream);
    mediaRecorder.ondataavailable = event => {
        if (event.data.size > 0) {
            recordedChunks.push(event.data);
        }
    };
    mediaRecorder.start();
}

// Função para parar a gravação do vídeo local e enviar para o servidor
function stopRecording() {
    mediaRecorder.stop();
    mediaRecorder.onstop = async () => {
        const blob = new Blob(recordedChunks, { type: 'video/webm' });
        const formData = new FormData();
        formData.append('video', blob, 'recording.webm');
        
        await fetch(`/upload/${roomId}/${userId}`, {
            method: 'POST',
            body: formData
        });
    };
}

// Função para alternar o estado de mudo do áudio
function toggleAudio() {
    isAudioMuted = !isAudioMuted;
    localStream.getAudioTracks()[0].enabled = !isAudioMuted;
    muteAudioButton.classList.toggle('muted', isAudioMuted);
    muteAudioButton.innerHTML = isAudioMuted ? '<i class="material-icons">mic_off</i>' : '<i class="material-icons">mic</i>';
    micMutedIcon.classList.toggle('active', isAudioMuted);
}

// Função para alternar o estado de mudo do vídeo
function toggleVideo() {
    isVideoMuted = !isVideoMuted;
    localStream.getVideoTracks()[0].enabled = !isVideoMuted;
    muteVideoButton.classList.toggle('muted', isVideoMuted);
    muteVideoButton.innerHTML = isVideoMuted ? '<i class="material-icons">videocam_off</i>' : '<i class="material-icons">videocam</i>';
    videoMutedIcon.classList.toggle('active', isVideoMuted);
}

// Função para sair da sala, parar a gravação e fechar a conexão peer-to-peer
function leaveRoom() {
    stopRecording();
    peerConnection.close();
    localStream.getTracks().forEach(track => track.stop());
    socket.emit('leave-room', roomId); // Emitir um evento para notificar o servidor
    leaveMessage.style.display = 'block';
    remoteVideo.style.display = 'none';
    localVideo.style.display = 'none';
    controls.style.display = 'none';
}

// Função para iniciar o medidor de áudio
function startAudioMeter() {
    const audioContext = new AudioContext();
    const mediaStreamSource = audioContext.createMediaStreamSource(localStream);
    const analyser = audioContext.createAnalyser();
    mediaStreamSource.connect(analyser);
    analyser.fftSize = 256;
    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    function draw() {
        requestAnimationFrame(draw);
        analyser.getByteFrequencyData(dataArray);
        let sum = 0;
        for (let i = 0; i < bufferLength; i++) {
            sum += dataArray[i];
        }
        const average = sum / bufferLength;
        audioMeter.style.height = `${average}px`;
        audioMeter.style.backgroundColor = average > 50 ? 'red' : 'green';
    }
    draw();
}

muteAudioButton.addEventListener('click', toggleAudio);
muteVideoButton.addEventListener('click', toggleVideo);
leaveRoomButton.addEventListener('click', leaveRoom);

// Inicia a gravação automaticamente quando o vídeo começa
socket.emit('join-room', roomId);
startVideo().then(startRecording);

// Para a gravação quando o usuário sai
window.addEventListener('beforeunload', stopRecording);

socket.on('user-left', () => {
    participantCount--;
    adjustVideoLayout();
});
